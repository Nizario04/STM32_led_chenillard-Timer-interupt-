/*
 * task.h
 *
 *  Created on: Mar 11, 2025
 *      Author: proo
 */

#ifndef INC_TASK_H_
#define INC_TASK_H_


void Task_Init(void);
void Task_Button(void);
void Task_Evolve(void);
void Task_LED(void);


#endif /* INC_TASK_H_ */
