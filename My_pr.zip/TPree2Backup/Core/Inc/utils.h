/*
 * utils.h
 *
 *  Created on: Feb 4, 2025
 *      Author: proo
 */

#ifndef INC_UTILS_H_
#define INC_UTILS_H_

void setup(void);
void loop();
void UTILS_WaitN10ms(int);

#endif /* INC_UTILS_H_ */
