/*
 * scheduler.h
 *
 *  Created on: Mar 11, 2025
 *      Author: proo
 */

#ifndef INC_SCHEDULER_H_
#define INC_SCHEDULER_H_

void scheduler_setup(void);

#endif /* INC_SCHEDULER_H_ */
