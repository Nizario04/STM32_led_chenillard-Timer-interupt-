/*
 * buton.h
 *
 *  Created on: Feb 5, 2025
 *      Author: proo
 */

#ifndef INC_BUTON_H_
#define INC_BUTON_H_

#include "main.h"


void BUTTON_Enable(void);
void BUTTON_Config(void);
int BUTTON_GetBlueLevel(void);
int BUTTON_GetBluePressed(void);
////////////////////////////////

typedef struct button {
	int isOn;
	int hasBeenPressed;
	GPIO_TypeDef* port;
	uint16_t pinNumber;
}BUTTON;

extern BUTTON joystick[5];

typedef enum direction{CENTER, DOWN, RIGHT, UP, LEFT}DIRECTION;

int BUTTON_GetValue(DIRECTION direction);

int BUTTON_GetPressed(DIRECTION direction);

#define BTN_CENTER_Pin GPIO_PIN_5
#define BTN_CENTER_GPIO_Port GPIOC
#define BTN_BOTTOM_Pin GPIO_PIN_11
#define BTN_BOTTOM_GPIO_Port GPIOB
#define BTN_RIGHT_Pin GPIO_PIN_9
#define BTN_RIGHT_GPIO_Port GPIOC
#define BTN_TOP_Pin GPIO_PIN_8
#define BTN_TOP_GPIO_Port GPIOC
#define BTN_LEFT_Pin GPIO_PIN_6
#define BTN_LEFT_GPIO_Port GPIOC



#endif /* INC_BUTON_H_ */
