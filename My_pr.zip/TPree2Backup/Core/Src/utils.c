/*
 * utils.c
 *
 *  Created on: Feb 4, 2025
 *      Author: proo
 */
#include "utils.h"
#include "LED.h"
#include "buton.h"


void setup(){
	LED_Enable();
	LED_Configure();

	BUTTON_Enable();
	BUTTON_Config();
}


int tableau[2]={1000000,500000};
int static i=0;
int static LED_State=0;
int GreenLED_state=0;
int time_blinking;
int gonzales=1000;
int FLIP=0;

void loop(){
/*
	LED_DriveGreen(GreenLED_state);
	GreenLED_state =1- GreenLED_state;
	UTILS_WaitN10ms(100);
	*/
/////////////////////////////////////////////
//	BUTTON_GetBlueLevel()== 1 ? LED_DriveGreen(1) : LED_DriveGreen(0);
/////////////////////////////////////////////
	UTILS_WaitN10ms(10);


	if(BUTTON_GetBlueLevel()==1){
			FLIP=1-FLIP;
	}

	if(FLIP==1){
		UTILS_WaitN10ms(100);
	}

	else{
	    UTILS_WaitN10ms(500);
	}

	LED_DriveGreen(GreenLED_state);
	GreenLED_state =1- GreenLED_state;

////////////////////////////////////////////////
	/*UTILS_WaitN10ms(tableau[i%2]);
	//Freak(tableau[i%2]);
	LED_DriveGreen(LED_State);
	LED_State=1-LED_State;
	if(BUTTON_GetBlueLevel()==1){
		i++;
		while((BUTTON_GetBlueLevel()==1)){};
	}
*/

}



void UTILS_WaitN10ms(int N){
	int n,i,s=0;
	for(n=1;n<=N;n++){
		for(i=0;i<2500;i++){
			s=s+i;
		}
	}
}
