/*
 * buton.c
 *
 *  Created on: Feb 5, 2025
 *      Author: proo
 */
#include "utils.h"
#include "LED.h"
#include "buton.h"
#include "stm32l4xx.h"
#include <stm32l4xx_hal.h>
#include <stdint.h>
#include "main.h"

extern int flip=0;


static int bb_prevalue=1;

 int BUTTON_GetBluePressed(){

	 int curr= HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13);//ke recupere l'etat actuele
	 int U_sike= (bb_prevalue && !curr) ? 1 : 0 ; //table de verite classique :)
	 bb_prevalue=curr; //j'update l'etat
	 return U_sike; //le service est pret

 }







void BUTTON_Enable(){
	// declaration of a pointer to an integer
	//volatile uint32_t *RCC_AHB2ENR = (volatile uint32_t*) 0x4002104C;   //int* RCC_AHB2ENR;
	// define address for the pointer :
	int* RCC_AHB2ENR;
	RCC_AHB2ENR= (int *) 0x4002104C;
	// apply a logical OR to enable GPIOD
	*RCC_AHB2ENR = *RCC_AHB2ENR |= (1 << 2);  //(*RCC_AHB2ENR) | 0x4
}
//volatile uint32_t *RCC_AHB2ENR = (volatile uint32_t*) 0x4002104C;

void BUTTON_Config(){
	GPIOC->MODER &= ~0x0c000000;
	GPIOC->PUPDR &= ~0x08000000;
	GPIOC->PUPDR |= 0x04000000;//pour ne marche pas avec (0x01 << 26)
}



int BUTTON_GetBlueLevel(){
	return HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_13)== GPIO_PIN_RESET ? 1 : 0;
}



///////////////////////////////////////////////////////////////////////////




int BUTTON_GetValue(DIRECTION direction) {
	return joystick[direction].isOn;
}

int BUTTON_GetPressed(DIRECTION direction) {
	int pressed;
	pressed=joystick[direction].hasBeenPressed;
 	 joystick[direction].hasBeenPressed=0;
 	 // when read, a button is no more pressed
 	 return pressed;
}


BUTTON joystick[5] = {
		{0,0,BTN_CENTER_GPIO_Port,BTN_CENTER_Pin},
		{0,0,BTN_BOTTOM_GPIO_Port,BTN_BOTTOM_Pin},
		{0,0,BTN_RIGHT_GPIO_Port,BTN_RIGHT_Pin},
		{0,0,BTN_TOP_GPIO_Port,BTN_TOP_Pin},
		{0,0,BTN_LEFT_GPIO_Port,BTN_LEFT_Pin}
};



void update(DIRECTION direction){


}




void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
    switch(GPIO_Pin) {
        case BTN_CENTER_Pin:
            if (HAL_GPIO_ReadPin(BTN_CENTER_GPIO_Port, BTN_CENTER_Pin) == GPIO_PIN_RESET) {
                joystick[CENTER].hasBeenPressed = 1;
                joystick[CENTER].isOn = 1;
            }
            else {
                joystick[CENTER].isOn = 0;
            }
            break;
        case BTN_TOP_Pin:
        	if (HAL_GPIO_ReadPin(BTN_TOP_GPIO_Port, BTN_TOP_Pin) == GPIO_PIN_RESET) {
        	    joystick[UP].hasBeenPressed = 1;
        	    joystick[UP].isOn = 1;
        	 }
        	else {
        	     joystick[UP].isOn = 0;
        	}
    }
}




