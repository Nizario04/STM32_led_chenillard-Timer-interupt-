/*
 * scheduler.c
 *
 *  Created on: Mar 11, 2025
 *      Author: proo
 */


#include "LED.h"
#include "utils.h"
#include "buton.h"
#include "stm32l4xx.h"
#include "task.h"
#include "scheduler.h"

static int tasknumber=0;

scheduler_setup(){
	tasknumber=(tasknumber+1)%3;

	switch (tasknumber){
	 case 0 : Task_LED();
	 break;
	 case 1 : Task_Button();
	 break;
	 case 2 : Task_Evolve();
	 break;
	 default:
		 break;
	}

}
