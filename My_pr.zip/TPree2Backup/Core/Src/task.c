/*
 * task.c
 *
 *  Created on: Mar 11, 2025
 *      Author: proo
 */

#include "LED.h"
#include "utils.h"

#include "stm32l4xx.h"
#include "task.h"
#include "stm32l4xx_hal_conf.h"
#include "utils.h"
#include "LED.h"
#include "buton.h"




typedef enum {
	GREEN_LED_OFF ,//(the green LED is switched off)
	GREEN_LED_SLOW ,//(slow blinking at 0,5 Hz)
	GREEN_LED_MEDIUM ,//(2 Hz) (so: 0,25s ON then 0,25s OFF…)
	GREEN_LED_FAST, //8 Hz)
}lstat;

static lstat Green_ledstate;


static int BB_Pressed;

static float GREEN_LED_Speed;

static int useless_state_vu_que_je_suis_fou;

static int etat_led=0;
static int coounter=0;

static int TimeInms=0;

//int static Position = 2;
float PositionSpeed = 7.0;
int static Position = 2;

typedef enum {
	DRAW_WAIT_LAUNCH,
	DRAW_ANIMATION,
	DRAW_BLINK,
	DRAW_RESULT,
}DrawState;

static DrawState Draw=DRAW_RESULT;


void Task_Init(){
	TimeInms+=15;
	if(joystick[CENTER].isOn ==1){
		Draw=DRAW_WAIT_LAUNCH;
	}

}



void Task_Button(){

	//BUTTON_GetBluePressed()== 1 ? LED_DriveGreen(1) : LED_DriveGreen(0);//test du bouton


	if(BUTTON_GetBluePressed()==1){
			BB_Pressed=1;

	}

}

/*
Task_Evolve(){
	useless_state_vu_que_je_suis_fou = (BB_Pressed+1)%4;
	switch(useless_state_vu_que_je_suis_fou){
	case 0: GREEN_LED_Speed=0.5f ;
	break;
	case 1: GREEN_LED_Speed=2.0f;
	break;
	case 2: GREEN_LED_Speed=8.0f ;
	break;
	case 3: LED_DriveGreen(1);
	break;
	default:
		break;
	}
}
*/

void Task_Evolve() {
	/*
    if (BB_Pressed==1) {
        switch (Green_ledstate) {
            case GREEN_LED_OFF:
            	Green_ledstate = GREEN_LED_SLOW;
                GREEN_LED_Speed = 0.5f;  // on prepare la vitesse pour le prochain appel

                break;
            case GREEN_LED_SLOW:
            	Green_ledstate = GREEN_LED_MEDIUM;
                GREEN_LED_Speed = 2.0f;

                break;
            case GREEN_LED_MEDIUM:
            	Green_ledstate = GREEN_LED_FAST;
                GREEN_LED_Speed = 8.0f;

                break;
            case GREEN_LED_FAST:
            default:
            	Green_ledstate = GREEN_LED_OFF;
                GREEN_LED_Speed = 0.0f;

                break;
        }

        BB_Pressed = 0;
    }
    */

	switch(Draw){
	case DRAW_WAIT_LAUNCH:
		TimeInms=0;
		Draw=DRAW_ANIMATION;
		int static Position = 2;
		break;
	case DRAW_ANIMATION:
		if(TimeInms>5000){
			Draw=DRAW_BLINK;

		}
		break;
	case DRAW_BLINK:
		if(TimeInms>6000){
			Draw=DRAW_RESULT;
		}
		break;
	case DRAW_RESULT:

		break;
	default:
		break;
	}

}


Task_LED(){
/*
	if (Green_ledstate == GREEN_LED_OFF) {    //etat initiale de green_led state
	    LED_DriveGreen(0);
	    return;
	}
	coounter+=15;


	float duree= 1000/(GREEN_LED_Speed*2);

	if(coounter>=duree){
		LED_DriveGreen(etat_led);
		etat_led=1-etat_led;
		coounter=0;
	}
}
*/


int speed[8]={0};
void Task_LED() {

	int static Position = 2;


    switch(Draw) {
        case DRAW_WAIT_LAUNCH:
            // Éteindre toutes les LEDs en mode attente
            LED_Set_Value_With_Int(0x00);
            //static int lastUpdateTime = 0;
            static int index_speed=5;
            break;

        /*case DRAW_ANIMATION:
            if (TimeInms - lastUpdateTime >= (1000 / PositionSpeed)) {
                // Met à jour la LED selon la position
                Position = (Position + 1) % 8;
                LED_Set_Value_With_Int(1 << Position);

                // Réduire la vitesse progressivement
                PositionSpeed -= 7.0 / (5000.0 / (1000 / PositionSpeed));


                lastUpdateTime = TimeInms;
            }
            break;
           */
        case DRAW_ANIMATION:
        	int static lastUpdate=0;
            if ((speed!=0)&&(lastUpdate!=1000)) {
                        // Met à jour la LED selon la position
               Position = (Position + 1) % 8;
               LED_Set_Value_With_Int(1 << Position);

                        // Réduire la vitesse progressivement
               PositionSpeed -= 7.0 / (5000.0 / (1000 / PositionSpeed));


                        lastUpdateTime = TimeInms;
                    }
                    break;

        case DRAW_BLINK:
            if ((TimeInms / 100) % 2 == 0) {
                LED_Set_Value_With_Int(1 << Position);  // LED allumee
            } else {
                LED_Set_Value_With_Int(0x00);  // LED eteinte
            }
            break;

        case DRAW_RESULT:
            LED_Set_Value_With_Int(1 << Position);  // Garde la LED finale allumee
            break;
    }

    LED_Update();  // Met à jour les LEDs sur la carte

}





